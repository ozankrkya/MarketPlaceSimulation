package executable;
import elements.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.*;
public class Main {
	public static Random myRandom;
	public static int invalidQueries;
	public static void main(String[] args) throws FileNotFoundException {
		
		Scanner reader = new Scanner(new File(args[0]));
		PrintStream writer = new PrintStream(new File(args[1]));
		
		ArrayList<Trader> traders = new ArrayList<Trader>();
		
		/**
		 * gets the first line of input and creates random object with given seed
		 */
		int seed = reader.nextInt();
		myRandom = new Random(seed);
		/**
		 * gets the second integer which is the fee of the market and creates the market object
		 */
		int fee = reader.nextInt();
		Market market = new Market(fee);
		/**
		 * reads the number of traders
		 */
		int numberOfUsers = reader.nextInt();
		/**
		 * reads the number of queries
		 */
		int numberOfQueries = reader.nextInt();
		/**
		 * creates the trader objects
		 */
		for (int i=0; i < numberOfUsers; i++) {
			double dollarAmount = reader.nextDouble();
			double PQoinAmount = reader.nextDouble();
			Trader trader = new Trader(dollarAmount,PQoinAmount);
			traders.add(trader);
		}
		/**
		 * reads the given input and does the necessary operations according to their process number
		 */
		int processNumber;
		for(int i =0 ; i < numberOfQueries; i++) {
			processNumber = reader.nextInt();
			if(processNumber == 10) {
				int buyingTraderID = reader.nextInt();
				double price = reader.nextDouble();
				double amount = reader.nextDouble();
				invalidQueries += traders.get(buyingTraderID).buy(amount, price, market);
				market.checkTransactions(traders);
			}
			else if (processNumber == 11) {
				int buyingTraderID = reader.nextInt();
				double amount = reader.nextDouble();
				if (market.getSellingOrders().isEmpty()) {
					invalidQueries += 1;
				}
				else {
					invalidQueries += traders.get(buyingTraderID).buy(amount, market.getSellingOrders().peek().getPrice(), market);
					market.checkTransactions(traders);
				}
			}
			else if (processNumber == 20) {
				int sellingTraderID = reader.nextInt();
				double price = reader.nextDouble();
				double amount = reader.nextDouble();
				invalidQueries += traders.get(sellingTraderID).sell(amount, price, market);
				market.checkTransactions(traders);
			}
			else if (processNumber == 21) {
				int sellingTraderID = reader.nextInt();
				double amount = reader.nextDouble();
				if (market.getBuyingOrders().isEmpty()) {
					invalidQueries += 1;
				}
				else {
					invalidQueries += traders.get(sellingTraderID).sell(amount, market.getBuyingOrders().peek().getPrice(), market);
					market.checkTransactions(traders);
				}
			}
			else if (processNumber == 3) {
				int depositTraderID = reader.nextInt();
				double amount = reader.nextDouble();
				traders.get(depositTraderID).deposit(amount);
			}
			else if (processNumber == 4) {
				int withdrawTraderID = reader.nextInt();
				double amount = reader.nextDouble();
				invalidQueries += traders.get(withdrawTraderID).withdraw(amount);
			}
			else if (processNumber == 5) {
				int traderID = reader.nextInt();
				writer.printf("Trader %d: %.5f$ %.5fPQ\n",traderID, (traders.get(traderID).getWallet().getBlockedDollars() + traders.get(traderID).getWallet().getDollars()),
						(traders.get(traderID).getWallet().getBlockedCoins() + traders.get(traderID).getWallet().getCoins()));
			}
			else if (processNumber == 777) {
				double givenAmount;
				for(Trader trader: traders) {
					givenAmount = myRandom.nextDouble()*10;
					trader.getWallet().setCoins(trader.getWallet().getCoins() + givenAmount);
				}
			}
			else if (processNumber == 666) {
				double priceToSet = reader.nextDouble();
				market.makeOpenMarketOperation(priceToSet, traders);
			}
			else if (processNumber == 500) {
				double totalDollars = 0 ;
				double totalPQoins = 0 ;
				for (BuyingOrder order : market.getBuyingOrders()) {
					totalDollars += order.getPrice()*order.getAmount();
				}
				for (SellingOrder order : market.getSellingOrders()) {
					totalPQoins += order.getAmount();
				}
				writer.printf("Current market size: %.5f %.5f\n",totalDollars, totalPQoins);
			}
			else if (processNumber == 501) {
				int totalTransactionNumber = 0;
				for (int c = 0; c < market.getTransactions().size(); c++) {
					totalTransactionNumber += 1;
				}
				writer.printf("Number of successful transactions: %d\n", totalTransactionNumber);
			}
			else if (processNumber == 502) {
				writer.printf("Number of invalid queries: %d\n",invalidQueries);
			}
			else if (processNumber == 505) {
				double currentBuyPrice = 0;
				double currentSellPrice = 0;
				double averagePrice = 0;
				if (market.getSellingOrders().isEmpty() && market.getBuyingOrders().isEmpty()) {
					currentBuyPrice = 0;
					currentSellPrice = 0;
					averagePrice = 0;
				}
				else if (!market.getSellingOrders().isEmpty() && market.getBuyingOrders().isEmpty()) {
					currentBuyPrice = market.getSellingOrders().peek().getPrice();
					currentSellPrice = 0;
					averagePrice = currentBuyPrice;
				}
				else if (market.getSellingOrders().isEmpty() && !market.getBuyingOrders().isEmpty()) {
					currentBuyPrice = 0;
					currentSellPrice = market.getBuyingOrders().peek().getPrice();
					averagePrice = currentSellPrice;
				}
				else if (!market.getSellingOrders().isEmpty() && !market.getBuyingOrders().isEmpty()) {
					currentBuyPrice = market.getSellingOrders().peek().getPrice();
					currentSellPrice = market.getBuyingOrders().peek().getPrice();
					averagePrice = (currentBuyPrice + currentSellPrice)/2.0;
				}
				writer.printf("Current prices: %.5f %.5f %.5f\n",currentBuyPrice, currentSellPrice, averagePrice);
			}
			else if (processNumber == 555) {
				for (Trader trader : traders) {
					double totalDollars = trader.getWallet().getDollars() + trader.getWallet().getBlockedDollars();
					double totalPQoins = trader.getWallet().getCoins() + trader.getWallet().getBlockedCoins();
					writer.printf("Trader %d: %.5f$ %.5fPQ\n",trader.getID(),totalDollars,totalPQoins);
				}
			}
		}	
		reader.close();
		writer.close();
	}
}
