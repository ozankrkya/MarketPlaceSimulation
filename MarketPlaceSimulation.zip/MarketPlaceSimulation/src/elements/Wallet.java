package elements;

public class Wallet {
	private double dollars;
	private double coins;
	private double blockedDollars;
	private double blockedCoins;
	/**
	 * Constructor for wallet objects
	 * @param dollars the amount of dollars when the wallet is created
	 * @param coins the amount of PQoins when the wallet is created
	 */
	public Wallet(double dollars, double coins) {
		this.dollars = dollars;
		this.coins = coins;
		this.blockedDollars = 0;
		this.blockedCoins = 0;
	}
	
	/**
	 * getter for current dollars of wallet
	 * @return dollars in the wallet
	 */
	public double getDollars() {
		return dollars;
	}
	/**
	 * setter for the current dollars in the wallet
	 * @param dollars the amount that the current dollars to be set
	 */
	public void setDollars(double dollars) {
		this.dollars = dollars;
	}

	/**
	 * @return the coins
	 */
	public double getCoins() {
		return coins;
	}

	/**
	 * @param coins the coins to set
	 */
	public void setCoins(double coins) {
		this.coins = coins;
	}

	/**
	 * @return the blockedDollars
	 */
	public double getBlockedDollars() {
		return blockedDollars;
	}

	/**
	 * @param blockedDollars the blockedDollars to set
	 */
	public void setBlockedDollars(double blockedDollars) {
		this.blockedDollars = blockedDollars;
	}

	/**
	 * @return the blockedCoins
	 */
	public double getBlockedCoins() {
		return blockedCoins;
	}

	/**
	 * @param blockedCoins the blockedCoins to set
	 */
	public void setBlockedCoins(double blockedCoins) {
		this.blockedCoins = blockedCoins;
	}

	
}
