package elements;

public class Order {
	double amount;
	double price;
	int traderID;
	/**
	 * Constructor for order objects , same for buying and selling
	 * @param traderID the id of the trader that gives the order
	 * @param amount the amount of PQoins to buy or sell
	 * @param price the price of PQoins for which to buy or sell
	 */
	public Order(int traderID, double amount, double price) {
		this.amount = amount;
		this.traderID = traderID;
		this.price = price;
	}
	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the traderID
	 */
	public int getTraderID() {
		return traderID;
	}
	/**
	 * @param traderID the traderID to set
	 */
	public void setTraderID(int traderID) {
		this.traderID = traderID;
	}
	

	
}

