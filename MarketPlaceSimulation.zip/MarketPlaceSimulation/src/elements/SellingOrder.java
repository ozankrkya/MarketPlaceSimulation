package elements;

public class SellingOrder extends Order implements Comparable<SellingOrder>{
	/**
	 * Constructor for SellingOrder objects by using the super's constructor
	 * @param traderID the id of the trader who gives the sell order
	 * @param amount the amount of PQoins to sell
	 * @param price the price of PQoins for which to sell
	 */
	public SellingOrder(int traderID, double amount, double price) {
		super(traderID, amount, price);
	}
	
	
	/**
	 * Overridden compareTo method to sort the sellingQueue field of the market with ascending selling prices
	 * @param other the other SellingOrder object to be compared with
	 */
	@Override
	public int compareTo(SellingOrder other) {
		if (this.price > other.price) {
			return 1;
		}
		else if (this.price < other.price) {
			return -1;
		}
		else {
			if (this.amount < other.amount) {
				return 1;
			}
			else if (this.amount > other.amount) {
				return -1;
			}
			else {
				if (this.traderID > other.traderID) {
					return 1;
				}
				else if (this.traderID < other.traderID) {
					return -1;
				}
				else {
					return 0;
				}
			}
		}
	}
	
}
