package elements;

public class BuyingOrder extends Order implements Comparable<BuyingOrder>{
	
	/**
	 * Constructor for BuyingOrder objects by using super's constructor.
	 * @param traderID the id of the trader who gives the buy order
	 * @param amount the amount of PQoins to buy
	 * @param price the price of PQoins for which to buy
	 */
	public BuyingOrder(int traderID, double amount, double price) {
		super(traderID, amount, price);
	}
	
	/**
	 * Overridden compareTo method from Comparable interface in order to sort buyingOrders queue with descending buying prices.
	 * @param other the other buying order object to be compared with.
	 */
	public int compareTo(BuyingOrder other) {
		if(this.price < other.price) {
			return 1;
		}
		else if (this.price > other.price) {
			return -1;
		}
		else {
			if (this.amount < other.amount) {
				return 1;
			}
			else if (this.amount > other.amount) {
				return -1;
			}
			else {
				if (this.traderID > other.traderID) {
					return 1;
				}
				else if (this.traderID < other.traderID) {
					return -1;
				}
				else {
					return 0;
				}
			}
		}
	}
}
