package elements;

import java.util.ArrayList;
import java.util.PriorityQueue;

public class Market {
	private int marketFee;
	private PriorityQueue<SellingOrder> sellingOrders;
	private PriorityQueue<BuyingOrder> buyingOrders;
	private ArrayList<Transaction> transactions;
	public int invalidByMethod = 0;
	/**
	 * Constructor for market objects
	 * @param fee the fee amount that is cut from what the sellers gets during transactions
	 */
	public Market(int fee) {
		this.marketFee = fee;
		this.sellingOrders = new PriorityQueue<SellingOrder>();
		this.buyingOrders = new PriorityQueue<BuyingOrder>();
		this.transactions = new ArrayList<Transaction>();
	}
	
	/**
	 * adds the given order to the sellingPQ
	 * @param order the order that is added to sellingPQ
	 */
	public void giveSellOrder(SellingOrder order) {
		sellingOrders.add(order);
	}
	
	/**
	 * adds the given order to the buyingPQ
	 * @param order the order that is added to buyingPQ
	 */
	public void giveBuyOrder(BuyingOrder order) {
		buyingOrders.add(order);
	}
	/**
	 * Checks the overlapping orders and if there is any, makes the transactions.
	 * @param traders is the ArrayList of all traders
	 */
	public void checkTransactions(ArrayList<Trader> traders) {
		while (true) {
			BuyingOrder bOrder;
			BuyingOrder bOrderX;
			SellingOrder sOrder;
			SellingOrder sOrderX;
			Transaction tAction;
		if (!buyingOrders.isEmpty() && !sellingOrders.isEmpty()) {
			if (buyingOrders.peek().price >= sellingOrders.peek().price) {
				// if amount of coins to be sold is more than wanted by the top of buying queue
				if (sellingOrders.peek().amount >= buyingOrders.peek().amount) {
					bOrder = buyingOrders.poll();
					sOrder = sellingOrders.poll();
						double blockedDollarsForThis = bOrder.amount*bOrder.price;
						double blockedDollarsSpent = bOrder.amount*sOrder.price;
						double blockedDollarsReturned = blockedDollarsForThis - blockedDollarsSpent;
						//Adds coins to buyer
						traders.get(bOrder.traderID).getWallet().setCoins(traders.get(bOrder.traderID).getWallet().getCoins() + bOrder.amount);
						//Deletes the spent blocked dollar from the buyer's wallet
						traders.get(bOrder.traderID).getWallet().setBlockedDollars(traders.get(bOrder.traderID).getWallet().getBlockedDollars() - blockedDollarsSpent);
						//Returns extra blocked amount to buyer's dollars
						traders.get(bOrder.traderID).getWallet().setDollars(traders.get(bOrder.traderID).getWallet().getDollars() + blockedDollarsReturned);
						//Adds dollars to seller
						traders.get(sOrder.traderID).getWallet().setDollars(traders.get(sOrder.traderID).getWallet().getDollars() + blockedDollarsSpent*(1-this.marketFee/1000.0));
						//Deletes sold amount of coins from seller's blocked coins
						traders.get(sOrder.traderID).getWallet().setBlockedCoins(traders.get(sOrder.traderID).getWallet().getBlockedCoins() - bOrder.amount);
						//Creates new sell order with the the coins that is not sold, then adds it to sellingOrder queue if selling amount is larger
						if (sOrder.amount > bOrder.amount) {
							sOrderX = new SellingOrder(sOrder.traderID , sOrder.amount-bOrder.amount, sOrder.price);
							sellingOrders.add(sOrderX);
							sOrder.amount = bOrder.amount;
							}	
						tAction = new Transaction(sOrder,bOrder);
						transactions.add(tAction);
						continue;
						}
				else if (sellingOrders.peek().amount < buyingOrders.peek().amount) {
					sOrder = sellingOrders.poll();
					bOrder = buyingOrders.poll();
					//Adds coins to buyer
					traders.get(bOrder.traderID).getWallet().setCoins(traders.get(bOrder.traderID).getWallet().getCoins() + sOrder.amount);
					//Deletes the spent blocked dollar from the buyer's wallet
					traders.get(bOrder.traderID).getWallet().setBlockedDollars(traders.get(bOrder.traderID).getWallet().getBlockedDollars() - sOrder.amount*sOrder.price);
					//Adds dollars to seller
					traders.get(sOrder.traderID).getWallet().setDollars(traders.get(sOrder.traderID).getWallet().getDollars() + sOrder.price*sOrder.amount*(1-this.marketFee/1000.0));
					//Deletes blocked coins sold from the seller's wallet 
					traders.get(sOrder.traderID).getWallet().setBlockedCoins(traders.get(sOrder.traderID).getWallet().getBlockedCoins()- sOrder.amount);
					//Creates new buy order with the wanted amount - bought amount from the seller, using old buying price
					//Recall equality of the amounts situation is handled above
					bOrderX = new BuyingOrder(bOrder.traderID ,bOrder.amount-sOrder.amount, bOrder.price);
					buyingOrders.add(bOrderX);
					bOrder.amount = sOrder.amount;
					tAction = new Transaction(sOrder,bOrder);
					transactions.add(tAction);
					continue;
					}
				}
			else {
				break;
				}
			}
		else {
			break;
		}
		}
		}
	/**
	 * Gives buying and selling orders until there is no buy order that has bigger price than the given price and there is no sell order that has lower price than 
	 * the given price.
	 * @param price the price that is wanted to market current price to be set around.
	 * @param traders ArrayList of all traders in simulation.
	 */
	public void makeOpenMarketOperation(double price, ArrayList<Trader> traders) {
		double currentBuyPrice = 0;
		double currentSellPrice = 0;
		if (this.getSellingOrders().isEmpty() && this.getBuyingOrders().isEmpty()) {
			currentBuyPrice = 0;
			currentSellPrice = 0;
		}
		else if (!this.getSellingOrders().isEmpty() && this.getBuyingOrders().isEmpty()) {
			currentBuyPrice = this.getSellingOrders().peek().getPrice();
			currentSellPrice = 0;
		}
		else if (this.getSellingOrders().isEmpty() && !this.getBuyingOrders().isEmpty()) {
			currentBuyPrice = 0;
			currentSellPrice = this.getBuyingOrders().peek().getPrice();
		}
		else if (!this.getSellingOrders().isEmpty() && !this.getBuyingOrders().isEmpty()) {
			currentBuyPrice = this.getSellingOrders().peek().getPrice();
			currentSellPrice = this.getBuyingOrders().peek().getPrice();
		}
		while (!(currentSellPrice > price && currentBuyPrice < price)) {
			if (!this.buyingOrders.isEmpty() && !this.sellingOrders.isEmpty()) {
				 if(currentBuyPrice > price) {
					 SellingOrder operationSell = new SellingOrder(0, buyingOrders.peek().amount, buyingOrders.peek().price);
					 sellingOrders.add(operationSell);
				 }
				 if (currentSellPrice < price) {
					 BuyingOrder operationBuy = new BuyingOrder(0, sellingOrders.peek().amount, sellingOrders.peek().price);
					 buyingOrders.add(operationBuy);
				 }
				 checkTransactions(traders);
			 }
			else {
				break;
			}
		}
	}


	/**
	 * @return the marketFee
	 */
	public int getMarketFee() {
		return marketFee;
	}


	/**
	 * @param marketFee the marketFee to set
	 */
	public void setMarketFee(int marketFee) {
		this.marketFee = marketFee;
	}


	/**
	 * @return the sellingOrders
	 */
	public PriorityQueue<SellingOrder> getSellingOrders() {
		return sellingOrders;
	}


	/**
	 * @param sellingOrders the sellingOrders to set
	 */
	public void setSellingOrders(PriorityQueue<SellingOrder> sellingOrders) {
		this.sellingOrders = sellingOrders;
	}


	/**
	 * @return the buyingOrders
	 */
	public PriorityQueue<BuyingOrder> getBuyingOrders() {
		return buyingOrders;
	}


	/**
	 * @param buyingOrders the buyingOrders to set
	 */
	public void setBuyingOrders(PriorityQueue<BuyingOrder> buyingOrders) {
		this.buyingOrders = buyingOrders;
	}


	/**
	 * @return the transactions
	 */
	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}


	/**
	 * @param transactions the transactions to set
	 */
	public void setTransactions(ArrayList<Transaction> transactions) {
		this.transactions = transactions;
	}


	
	
}
