package elements;

public class Trader {
	private int ID;
	private Wallet wallet;
	public static int numberOfUsers = 0;
	public Trader(double dollars, double coins) {
		this.wallet = new Wallet(dollars, coins);
		this.ID = numberOfUsers;
		numberOfUsers++;
	}
	/**
	 * sell method for traders in order to sell PQoins with given parameters.
	 * @param amount the amount of PQoins which is wanted to sell
	 * @param price the price of PQoins to be sold per each
	 * @param market the market where the PQoins to be sold at
	 * @return 1 if selling process is invalid 
	 * @return 0 if selling process is valid
	 */
	public int sell(double amount, double price, Market market) {
		if(this.ID!=0) {
			if(amount <= this.wallet.getCoins() && amount != 0) {
				this.wallet.setCoins(this.wallet.getCoins()-amount);
				this.wallet.setBlockedCoins(this.wallet.getBlockedCoins()+amount);
				SellingOrder newOrder = new SellingOrder(this.ID, amount, price);
				market.giveSellOrder(newOrder);
				return 0;
			}
			else {
				return 1;
			}
		}
		else {
			SellingOrder newOrder = new SellingOrder(this.ID, amount, price);
			market.giveSellOrder(newOrder);
			return 0;
		}
	}
	/**
	 * buy method for traders in order to buy PQoins with given parameters.
	 * @param amount the amount of PQoins which is wanted to buy
	 * @param price the price of PQoins to be bought per each
	 * @param market the market where the PQoins to be bought at
	 * @return
	 */
	public int buy(double amount, double price, Market market) {
		if(this.ID!=0) {
			if(this.wallet.getDollars() >= amount*price && amount != 0) {
				this.wallet.setDollars(this.wallet.getDollars() - amount*price);
				this.wallet.setBlockedDollars(this.wallet.getBlockedDollars() + amount*price);
				BuyingOrder newOrder = new BuyingOrder(this.ID, amount,price);
				market.giveBuyOrder(newOrder);
				return 0;
			}
			else {
				return 1;
			}
		}
		else {
			BuyingOrder newOrder = new BuyingOrder(this.ID, amount,price);
			market.giveBuyOrder(newOrder);
			return 0;
		}
	}
	/**
	 * deposit method which takes amount of dollars to be deposited and adds the given amount to the traders wallet
	 * @param amount the amount of deposited dollars
	 */
	public void deposit(double amount) {
		this.wallet.setDollars(this.wallet.getDollars() + amount);
	}
	/**
	 * trader withdraws the given amount of dollars if herself/himself has enough dollars
	 * @param amount the amount which is wanted to be withdrew
	 * @return 1 if process is invalid
	 * @return 0 if process is valid
	 */
	public int withdraw(double amount) {
		if(this.wallet.getDollars() >= amount) {
			this.wallet.setDollars(this.wallet.getDollars()-amount);
			return 0;
		}
		else {
			return 1;
		}
	}
	
	

	/**
	 * @return the iD
	 */
	public int getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(int iD) {
		ID = iD;
	}

	/**
	 * @return the wallet
	 */
	public Wallet getWallet() {
		return wallet;
	}

	/**
	 * @param wallet the wallet to set
	 */
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

}
